default_app_config = 'wagtail.contrib.forms.apps.WagtailFormsAppConfig'
