default_app_config = 'wagtail.contrib.redirects.apps.WagtailRedirectsAppConfig'
