default_app_config = 'wagtail.admin.apps.WagtailAdminAppConfig'
