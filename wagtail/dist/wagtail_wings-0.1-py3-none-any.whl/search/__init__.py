default_app_config = 'wagtail.search.apps.WagtailSearchAppConfig'
