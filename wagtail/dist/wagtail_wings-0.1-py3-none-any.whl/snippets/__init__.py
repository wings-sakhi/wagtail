default_app_config = 'wagtail.snippets.apps.WagtailSnippetsAppConfig'
