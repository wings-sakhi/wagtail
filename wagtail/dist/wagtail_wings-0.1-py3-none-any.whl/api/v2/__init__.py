default_app_config = 'wagtail.api.v2.apps.WagtailAPIV2AppConfig'
