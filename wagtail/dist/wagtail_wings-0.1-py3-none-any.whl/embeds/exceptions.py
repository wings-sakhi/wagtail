
class EmbedException(Exception):
    pass


class EmbedUnsupportedProviderException(EmbedException):
    pass


class EmbedNotFoundException(EmbedException):
    pass
