default_app_config = 'wagtail.contrib.search_promotions.apps.WagtailSearchPromotionsAppConfig'
