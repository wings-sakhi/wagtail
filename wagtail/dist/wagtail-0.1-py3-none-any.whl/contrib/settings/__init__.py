default_app_config = 'wagtail.contrib.settings.apps.WagtailSettingsAppConfig'
