default_app_config = 'wagtail.contrib.routable_page.apps.WagtailRoutablePageAppConfig'
