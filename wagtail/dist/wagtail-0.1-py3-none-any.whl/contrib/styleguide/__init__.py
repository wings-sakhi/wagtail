default_app_config = 'wagtail.contrib.styleguide.apps.WagtailStyleGuideAppConfig'
