default_app_config = 'wagtail.sites.apps.WagtailSitesAppConfig'
