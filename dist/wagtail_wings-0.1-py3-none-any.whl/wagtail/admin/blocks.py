import warnings

from wagtail.core.blocks import *  # noqa

warnings.warn("wagtail.admin.blocks has moved to wagtail.core.blocks", UserWarning, stacklevel=2)
