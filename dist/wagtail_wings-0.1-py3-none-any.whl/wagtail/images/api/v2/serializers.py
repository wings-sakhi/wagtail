from wagtail.api.v2.serializers import BaseSerializer


class ImageSerializer(BaseSerializer):
    pass
