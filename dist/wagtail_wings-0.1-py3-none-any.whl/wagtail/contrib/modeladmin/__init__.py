default_app_config = 'wagtail.contrib.modeladmin.apps.WagtailModelAdminAppConfig'
