default_app_config = 'wagtail.contrib.table_block.apps.WagtailTableBlockAppConfig'
