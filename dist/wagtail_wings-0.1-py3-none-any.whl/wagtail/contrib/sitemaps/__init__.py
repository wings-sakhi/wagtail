from .sitemap_generator import Sitemap  # noqa


default_app_config = 'wagtail.contrib.sitemaps.apps.WagtailSitemapsAppConfig'
