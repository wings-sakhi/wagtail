default_app_config = 'wagtail.contrib.frontend_cache.apps.WagtailFrontendCacheAppConfig'
